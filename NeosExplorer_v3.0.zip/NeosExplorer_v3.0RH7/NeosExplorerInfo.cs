﻿using System;
using System.Drawing;
using Grasshopper;
using Grasshopper.Kernel;
using NeosExplorer.Properties;

namespace NeosExplorer_RH7
{
    public class NeosExplorerInfo : GH_AssemblyInfo
    {
        public override string Name => "NeosExplorer";

        //Return a 24x24 pixel bitmap to represent this GHA library.
        public override Bitmap Icon => Resources.iconEXPSIM;

        //Return a short string describing the purpose of this GHA library.
        public override string Description => "Tools for pedestrian simulation";

        public override Guid Id => new Guid("A464EBB1-405B-4881-9C25-2DC16AEDC864");

        //Return a string identifying you or your company.
        public override string AuthorName => "Huafei Huang";

        //Return a string representing your preferred contact details.
        public override string AuthorContact => "wongwahfai@163.com";

        //Return a string representing the version.  This returns the same version as the assembly.
        public override string AssemblyVersion => GetType().Assembly.GetName().Version.ToString();
    }
}